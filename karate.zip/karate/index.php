<?php

header('Location: dashboard/');
?>
