<footer class="main-footer">
    <strong>Copyright &copy; 2023
        <a href="https://www.facebook.com/PHATCHARAPHONG2000" target="_blank">PATCHARAPHONGDEV</a>.
    </strong> All rights reserved.
</footer>