<?php
/**
 * AppzStory Back Office Management System Template
 *
 * @link https://appzstory.dev
 * @author Yothin Sapsamran (Jame AppzStory Studio)
 */
header('Location: dashboard/');
?>
// เริ่ม session
// session_start();

// if (isset($_SESSION['AD_ADMIN'])) {
// $role = $_SESSION['AD_ADMIN'];


// switch ($role) {
// case 'taekwondo':
// header('Location: taekwondo/');
// break;
// case 'karate':
// header('Location: karate/');
// break;
// case 'gymnastic':
// header('Location: gymnastic/');
// break;
// default:
// header('Location: login.php');
// break;
// }
// } else {
// header('Location: login.php');
// }