<?php 
    /**
     * Main Footer
     * 
     * @link https://appzstory.dev
     * @author Yothin Sapsamran (Jame AppzStory Studio)
     */
    require_once('../authen.php'); 
?>
<footer class="main-footer">
    <strong>Copyright &copy; 2021 - 2023
        <a href="https://www.facebook.com/PHATCHARAPHONG2000" target="_blank">PATCHARAPHONG.DAV</a>.
    </strong> All rights reserved.
</footer>